package com_pcwk_ehr_cmn;

public class DTO {

}
