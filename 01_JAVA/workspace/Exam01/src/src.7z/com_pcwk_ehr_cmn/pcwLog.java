package com_pcwk_ehr_cmn;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


	public interface pcwLog {
	Logger LOG = LogManager.getLogger();
	


}